﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PROVADASILVA
{
    public partial class Form1 : Form
    {

        private string value;
        
       

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[3, 3];



            for (int i = 0; i < 3; i++)
            {

                for (int j = 0; j < 3; j++)
                {
                    valores[i, j] = Convert.ToDouble(Interaction.InputBox($"Digite o valor do notebook {i + 1} na loja {j + 1}:"));

                    if (string.IsNullOrEmpty(value, out valores))
                    {
                        MessageBox.Show("Insira um valor que não seja nulo.");
                        j--;
                    }
                    else if (!int.TryParse(value, out valores))
                    {
                        MessageBox.Show("Insira um valor inteiro válido.");
                        j--;
                    }
                    else if (valores >= 0)
                    {
                        MessageBox.Show("Insira um valor maior ou igual a 0.");
                        j--;
                    }
                    else
                    {
                        
                        for (int n = 0; n < 3; n++)
                        {
                            double mediaModelo = 0;
                            for (int m = 0; m< 3; m++)
                            {
                                mediaModelo += valores[n, m];
                            }
                            mediaModelo /= 3;
                            lstboxvalores.Items.Add($"Notebook {n + 1}: Loja 1 = {valores[n, 0]:F2}, Loja 2 = {valores[n, 1]:F2}, Loja 3 = {valores[n, 2]:F2}, Media = {mediaModelo:F2}");
                        }
                    }

                    double mediaGeral = 0;
                    for (int r = 0; r < 3; r++)
                    {
                        for (int s = 0; s < 3; s++)
                        {
                            mediaGeral += valores[r, s];
                        }
                    }

                    mediaGeral /= 9;
                    lstboxvalores.Items.Add($"Media geral: {mediaGeral:F2}");
                }
            }


        }
       
        private void btnlimpar_Click(object sender, EventArgs e) =>
            lstboxvalores.Items.Clear();

    }

}

