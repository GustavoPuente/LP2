﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercicioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void coLARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei na opção colar");
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei na opção copiar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close ();   
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                MessageBox.Show("form já exite");
                Application.OpenForms["frmexercicio2"].BringToFront();
            }
            else
            {
                FrmExercicio2 obj2 = new FrmExercicio2();
                obj2            .MdiParent = this;
                obj2.WindowState=FormWindowState.Maximized;
                obj2.Show(); 
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                MessageBox.Show("form já exite");
                Application.OpenForms["frmexercicio3"].BringToFront();
            }
            else
            {
                FrmExercicio3 obj3 = new FrmExercicio3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                MessageBox.Show("form já exite");
                Application.OpenForms["frmexercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 obj4 = new FrmExercicio4();
                obj4.MdiParent = this;
                obj4. WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                MessageBox.Show("form já exite");
                Application.OpenForms["frmexercicio5"].BringToFront();
            }
            else
            {
                FrmExercicio5 obj5 = new FrmExercicio5();
                obj5.MdiParent = this;
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }
    }
}
