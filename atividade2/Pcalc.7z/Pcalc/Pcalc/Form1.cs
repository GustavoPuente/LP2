﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {

        double numero1, numero2, resultado; 
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero !!",
                "ERRO",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnum2.Text = "";
                txtnum2.Focus();
            }
            else
            {
                errorProvider2.SetError(txtnum2, "");
                resultado = numero1 / numero2;
                txtresult.Text = resultado.ToString();
            }
        }
        private void bntsomar_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtnum2, "");
            resultado = numero1 + numero2;
            txtresult.Text = resultado.ToString();
    
            
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            
            if (MessageBox.Show("você deseja sair mesmo?", "saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                Close();
            }

                

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtresult.Clear ();
        }

        private void txtnum2_Validated(object sender, EventArgs e)
        {
            try
            {
                numero2 = Convert.ToDouble(txtnum2.Text);
            }
            catch   (Exception ex) 
            {
                errorProvider2.SetError(txtnum2, "numero 2 inválido");
                MessageBox.Show("Numero inválido");
                txtnum2.Focus();
            }

        }

        private void txtnum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void bntsubtrair_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtnum2, "");
            resultado = numero1 - numero2;
            txtresult.Text = resultado.ToString();
        }

        private void bntmult_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtnum2, "");
            resultado = numero1 * numero2;
            txtresult.Text = resultado.ToString();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtnum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum1.Text, out numero1))
            {
                errorProvider1.SetError(txtnum1, "numero 1 inválido");
                MessageBox.Show("numero inválido");
                txtnum1.Focus();
            }
            else
                errorProvider1.SetError(txtnum1, "");

        }
    }
}       