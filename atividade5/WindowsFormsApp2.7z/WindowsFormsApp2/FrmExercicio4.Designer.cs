﻿namespace WindowsFormsApp2
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RCHTXT = new System.Windows.Forms.RichTextBox();
            this.btncontanum = new System.Windows.Forms.Button();
            this.btncontaletra = new System.Windows.Forms.Button();
            this.btncontabranco = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RCHTXT
            // 
            this.RCHTXT.Location = new System.Drawing.Point(322, 130);
            this.RCHTXT.Name = "RCHTXT";
            this.RCHTXT.Size = new System.Drawing.Size(100, 96);
            this.RCHTXT.TabIndex = 0;
            this.RCHTXT.Text = "";
            // 
            // btncontanum
            // 
            this.btncontanum.Location = new System.Drawing.Point(176, 335);
            this.btncontanum.Name = "btncontanum";
            this.btncontanum.Size = new System.Drawing.Size(133, 37);
            this.btncontanum.TabIndex = 1;
            this.btncontanum.Text = "contar numeros";
            this.btncontanum.UseVisualStyleBackColor = true;
            this.btncontanum.Click += new System.EventHandler(this.btncontanum_Click);
            // 
            // btncontaletra
            // 
            this.btncontaletra.Location = new System.Drawing.Point(360, 335);
            this.btncontaletra.Name = "btncontaletra";
            this.btncontaletra.Size = new System.Drawing.Size(133, 37);
            this.btncontaletra.TabIndex = 2;
            this.btncontaletra.Text = "contar letras";
            this.btncontaletra.UseVisualStyleBackColor = true;
            // 
            // btncontabranco
            // 
            this.btncontabranco.Location = new System.Drawing.Point(549, 334);
            this.btncontabranco.Name = "btncontabranco";
            this.btncontabranco.Size = new System.Drawing.Size(134, 38);
            this.btncontabranco.TabIndex = 3;
            this.btncontabranco.Text = "contar espaços em branco";
            this.btncontabranco.UseVisualStyleBackColor = true;
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btncontabranco);
            this.Controls.Add(this.btncontaletra);
            this.Controls.Add(this.btncontanum);
            this.Controls.Add(this.RCHTXT);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RCHTXT;
        private System.Windows.Forms.Button btncontanum;
        private System.Windows.Forms.Button btncontaletra;
        private System.Windows.Forms.Button btncontabranco;
    }
}