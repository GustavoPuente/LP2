﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxpeso.Text, out peso))
            {
                MessageBox.Show("Entrada Inválida");
                mskbxpeso.Focus();
            }
        }

        private void mskbxpeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskboxaltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskboxaltura.Text, out altura))
            {
                MessageBox.Show("Entrada Inválida");
                mskboxaltura.Focus();
            }
        }

        private void Btncalc_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            txtimc.Text = imc.ToString("N2");

            if (imc < 18.5)
                MessageBox.Show("Magreza");
            
                else
                {
                    if( imc < 24.9)
                    MessageBox.Show("Normal");
                else
                {
                    if ( imc < 29.9)
                    MessageBox.Show("Sobrepeso");
                else
                    {
                    if (imc < 39.9)
                    MessageBox.Show("Obesidade");
                        else
                        {
                            MessageBox.Show("obesidade Grave");
                        }
                    }    
                }
            }
             
                
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mskboxaltura.Clear();
            mskbxpeso.Clear ();
            txtimc.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
