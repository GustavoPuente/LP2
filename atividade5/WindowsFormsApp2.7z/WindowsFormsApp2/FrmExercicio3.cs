﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnretornar_Click(object sender, EventArgs e)
        {
            char[] vetor = txtpalavra1.Text.ToCharArray ();
          
            Array.Reverse(vetor); ;

            foreach(char c in vetor)
            {
                txtpalavra2.Text += c;
            }
        }

        private void btnremover_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra2.Text.Length / 2;
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text);
        }
    }
}
