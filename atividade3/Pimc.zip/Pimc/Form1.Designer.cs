﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btncalc = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.lvlPeso = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.lblIMC = new System.Windows.Forms.Label();
            this.mskboxaltura = new System.Windows.Forms.MaskedTextBox();
            this.mskbxpeso = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Btncalc
            // 
            this.Btncalc.Location = new System.Drawing.Point(319, 321);
            this.Btncalc.Name = "Btncalc";
            this.Btncalc.Size = new System.Drawing.Size(111, 54);
            this.Btncalc.TabIndex = 0;
            this.Btncalc.Text = "Calcular";
            this.Btncalc.UseVisualStyleBackColor = true;
            this.Btncalc.Click += new System.EventHandler(this.Btncalc_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(476, 321);
            this.button2.Name = "button2";
            this.button2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button2.Size = new System.Drawing.Size(114, 54);
            this.button2.TabIndex = 1;
            this.button2.Text = "Limpar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(626, 321);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(113, 54);
            this.button3.TabIndex = 2;
            this.button3.Text = "Sair";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lvlPeso
            // 
            this.lvlPeso.AutoSize = true;
            this.lvlPeso.Location = new System.Drawing.Point(404, 88);
            this.lvlPeso.Name = "lvlPeso";
            this.lvlPeso.Size = new System.Drawing.Size(58, 13);
            this.lvlPeso.TabIndex = 3;
            this.lvlPeso.Text = "Peso Atual";
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(404, 141);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(34, 13);
            this.lblAltura.TabIndex = 4;
            this.lblAltura.Text = "Altura";
            // 
            // lblIMC
            // 
            this.lblIMC.AutoSize = true;
            this.lblIMC.Location = new System.Drawing.Point(404, 189);
            this.lblIMC.Name = "lblIMC";
            this.lblIMC.Size = new System.Drawing.Size(26, 13);
            this.lblIMC.TabIndex = 5;
            this.lblIMC.Text = "IMC";
            this.lblIMC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // mskboxaltura
            // 
            this.mskboxaltura.Location = new System.Drawing.Point(476, 134);
            this.mskboxaltura.Mask = "0.00";
            this.mskboxaltura.Name = "mskboxaltura";
            this.mskboxaltura.Size = new System.Drawing.Size(100, 20);
            this.mskboxaltura.TabIndex = 6;
            this.mskboxaltura.ValidatingType = typeof(int);
            this.mskboxaltura.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            this.mskboxaltura.Validated += new System.EventHandler(this.mskboxaltura_Validated);
            // 
            // mskbxpeso
            // 
            this.mskbxpeso.Location = new System.Drawing.Point(476, 85);
            this.mskbxpeso.Mask = "000.00";
            this.mskbxpeso.Name = "mskbxpeso";
            this.mskbxpeso.Size = new System.Drawing.Size(100, 20);
            this.mskbxpeso.TabIndex = 7;
            this.mskbxpeso.ValidatingType = typeof(int);
            this.mskbxpeso.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskbxpeso_MaskInputRejected);
            this.mskbxpeso.Validated += new System.EventHandler(this.maskedTextBox2_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(476, 189);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(100, 20);
            this.txtimc.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 557);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskbxpeso);
            this.Controls.Add(this.mskboxaltura);
            this.Controls.Add(this.lblIMC);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lvlPeso);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Btncalc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btncalc;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lvlPeso;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.Label lblIMC;
        private System.Windows.Forms.MaskedTextBox mskboxaltura;
        private System.Windows.Forms.MaskedTextBox mskbxpeso;
        private System.Windows.Forms.TextBox txtimc;
    }
}

