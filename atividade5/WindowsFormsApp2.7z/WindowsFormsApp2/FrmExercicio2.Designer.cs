﻿namespace WindowsFormsApp2
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btniguais = new System.Windows.Forms.Button();
            this.btninserir = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(172, 89);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(48, 13);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "palavra1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(172, 128);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(48, 13);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "palavra2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(271, 82);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(271, 128);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(271, 166);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 4;
            // 
            // btniguais
            // 
            this.btniguais.Location = new System.Drawing.Point(123, 284);
            this.btniguais.Name = "btniguais";
            this.btniguais.Size = new System.Drawing.Size(84, 43);
            this.btniguais.TabIndex = 5;
            this.btniguais.Text = "verificar";
            this.btniguais.UseVisualStyleBackColor = true;
            // 
            // btninserir
            // 
            this.btninserir.Location = new System.Drawing.Point(297, 284);
            this.btninserir.Name = "btninserir";
            this.btninserir.Size = new System.Drawing.Size(84, 43);
            this.btninserir.TabIndex = 6;
            this.btninserir.Text = "inserir 1 meio 2";
            this.btninserir.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(481, 284);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 43);
            this.button3.TabIndex = 7;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btninserir);
            this.Controls.Add(this.btniguais);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btniguais;
        private System.Windows.Forms.Button btninserir;
        private System.Windows.Forms.Button button3;
    }
}